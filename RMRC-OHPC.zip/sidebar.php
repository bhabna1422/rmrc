<div class="sidebar" id="sidebar">
		<div class="sidebar-inner slimscroll">
			<div id="sidebar-menu" class="sidebar-menu">
				<ul>
					<li class="active"><a href="dashboard.php" ><i class="feather-grid"></i> <span>Dashboard</span></a></li>
					<!-- <li class="active"><a href="datatable.html"><i class="feather-align-justify"></i> <span>Datatable</span></a></li>
					<li><a href="table.html"><i class="feather-align-justify"></i> <span>Table</span></a></li>
					<li><a href="forms.html"><i class="feather-file-text"></i> <span>Forms</span></a></li>	
					<li><a href="components.html"><i class="feather-file-text"></i> <span>Components</span></a></li> -->
				</ul>	
			</div>	
		</div>	
	</div>